package sample.GUI;

public class DataManager {


    public DataManager()
    {

    }


}
