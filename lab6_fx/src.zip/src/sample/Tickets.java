package sample;

import java.io.Serializable;

public class Tickets implements Serializable {


    public Tickets()
    {
        String startStation;
        String endStation;
        int prize;




    }

}
